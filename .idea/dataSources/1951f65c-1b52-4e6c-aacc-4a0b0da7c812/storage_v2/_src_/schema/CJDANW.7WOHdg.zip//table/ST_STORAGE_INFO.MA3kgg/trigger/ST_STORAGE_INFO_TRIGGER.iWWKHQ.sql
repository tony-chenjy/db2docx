create trigger ST_STORAGE_INFO_TRIGGER
  before insert
  on ST_STORAGE_INFO
  for each row
begin       
select ST_STORAGE_INFO_SEQ.nextval into :new.sort from dual;      
end ;
/

