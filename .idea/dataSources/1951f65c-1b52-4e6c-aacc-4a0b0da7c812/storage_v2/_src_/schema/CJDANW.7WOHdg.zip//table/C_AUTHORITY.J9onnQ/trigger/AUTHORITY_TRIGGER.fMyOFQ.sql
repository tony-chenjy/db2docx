create trigger AUTHORITY_TRIGGER
  before insert
  on C_AUTHORITY
  for each row
begin       
select authority_seq.nextval into :new.sort from dual;      
end ;
/

