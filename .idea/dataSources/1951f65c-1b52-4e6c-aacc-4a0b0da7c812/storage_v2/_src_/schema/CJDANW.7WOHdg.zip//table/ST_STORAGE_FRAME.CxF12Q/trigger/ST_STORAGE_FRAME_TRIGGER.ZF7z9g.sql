create trigger ST_STORAGE_FRAME_TRIGGER
  before insert
  on ST_STORAGE_FRAME
  for each row
begin       
select ST_STORAGE_FRAME_SEQ.nextval into :new.id from dual;      
end ;
/

