create trigger SYS_WHITE_DOMAIN_TRIGGER
  before insert
  on SYS_WHITE_DOMAIN
  for each row
begin       
select sys_white_domain_seq.nextval into :new.sort from dual;      
end ;
/

