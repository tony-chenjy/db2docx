create trigger PROJECT_TRANSFER_TRIGGER
  before insert
  on PROJECT_TRANSFER
  for each row
begin       
select PROJECT_TRANSFER_SEQ.nextval into :new.sort from dual;      
end ;
/

