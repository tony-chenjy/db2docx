create trigger PROJECT_ARCH_FILE_TRIGGER
  before insert
  on PROJECT_ARCH_FILE
  for each row
begin       
select PROJECT_ARCH_FILE_SEQ.nextval into :new.sort from dual;      
end ;
/

