create trigger PROJECT_IMPORT_TRIGGER
  before insert
  on PROJECT_IMPORT
  for each row
begin       
select PROJECT_IMPORT_SEQ.nextval into :new.sort from dual;      
end ;
/

