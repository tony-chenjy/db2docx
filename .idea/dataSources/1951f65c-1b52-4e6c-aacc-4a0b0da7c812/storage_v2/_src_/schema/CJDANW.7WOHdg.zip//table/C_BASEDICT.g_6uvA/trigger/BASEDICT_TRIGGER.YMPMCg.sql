create trigger BASEDICT_TRIGGER
  before insert
  on C_BASEDICT
  for each row
begin       
select basedict_seq.nextval into :new.sort from dual;      
end ;
/

