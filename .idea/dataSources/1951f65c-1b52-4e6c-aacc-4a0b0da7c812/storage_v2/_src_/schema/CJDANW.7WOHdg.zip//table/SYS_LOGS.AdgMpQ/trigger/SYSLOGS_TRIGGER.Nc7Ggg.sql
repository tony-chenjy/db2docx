create trigger SYSLOGS_TRIGGER
  before insert
  on SYS_LOGS
  for each row
begin       
select syslogs_seq.nextval into :new.id from dual;      
end ;
/

