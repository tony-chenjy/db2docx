create trigger UNITS_TRIGGER
  before insert
  on C_UNIT
  for each row
begin       
select unit_seq.nextval into :new.sort from dual;      
end ;
/

