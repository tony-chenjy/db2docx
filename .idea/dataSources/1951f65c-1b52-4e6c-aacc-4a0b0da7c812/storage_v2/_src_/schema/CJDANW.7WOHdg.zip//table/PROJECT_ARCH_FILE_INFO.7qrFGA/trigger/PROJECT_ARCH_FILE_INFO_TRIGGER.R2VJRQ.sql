create trigger PROJECT_ARCH_FILE_INFO_TRIGGER
  before insert
  on PROJECT_ARCH_FILE_INFO
  for each row
begin       
select PROJECT_ARCH_FILE_INFO_SEQ.nextval into :new.sort from dual;      
end ;
/

