create trigger LOGIN_LOG_TRIGGER
  before insert
  on C_LOGIN_LOG
  for each row
begin       
select login_log_seq.nextval into :new.ID from dual;      
end ;
/

