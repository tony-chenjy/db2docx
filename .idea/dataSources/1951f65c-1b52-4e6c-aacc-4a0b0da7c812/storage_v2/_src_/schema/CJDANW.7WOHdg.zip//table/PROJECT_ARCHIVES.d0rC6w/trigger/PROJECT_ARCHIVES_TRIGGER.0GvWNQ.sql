create trigger PROJECT_ARCHIVES_TRIGGER
  before insert
  on PROJECT_ARCHIVES
  for each row
begin       
select PROJECT_ARCHIVES_SEQ.nextval into :new.sort from dual;      
end ;
/

