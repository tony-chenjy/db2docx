create trigger PROJECT_INFO_TRIGGER
  before insert
  on PROJECT_INFO
  for each row
begin       
select PROJECT_INFO_SEQ.nextval into :new.sort from dual;      
end ;
/

