create trigger USER_TRIGGER
  before insert
  on C_USER
  for each row
begin       
select user_seq.nextval into :new.sort from dual;      
end ;
/

