create trigger ROLE_TRIGGER
  before insert
  on C_ROLE
  for each row
begin       
select role_seq.nextval into :new.sort from dual;      
end ;
/

