create trigger ST_STORAGE_SHELF_TRIGGER
  before insert
  on ST_STORAGE_SHELF
  for each row
begin       
select PROJECT_PART_INFO_SEQ.nextval into :new.sort from dual;      
end ;
/

