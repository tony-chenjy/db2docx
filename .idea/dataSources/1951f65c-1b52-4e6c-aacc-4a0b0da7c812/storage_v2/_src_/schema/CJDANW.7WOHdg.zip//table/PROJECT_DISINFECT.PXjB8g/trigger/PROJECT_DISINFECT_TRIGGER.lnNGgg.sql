create trigger PROJECT_DISINFECT_TRIGGER
  before insert
  on PROJECT_DISINFECT
  for each row
begin       
select PROJECT_DISINFECT_SEQ.nextval into :new.sort from dual;      
end ;
/

