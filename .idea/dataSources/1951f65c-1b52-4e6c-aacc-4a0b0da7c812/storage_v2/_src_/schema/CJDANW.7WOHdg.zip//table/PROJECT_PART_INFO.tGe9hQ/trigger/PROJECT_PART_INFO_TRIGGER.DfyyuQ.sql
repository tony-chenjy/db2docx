create trigger PROJECT_PART_INFO_TRIGGER
  before insert
  on PROJECT_PART_INFO
  for each row
begin       
select PROJECT_PART_INFO_SEQ.nextval into :new.sort from dual;      
end ;
/

