create trigger ZONEPATH_TRIGGER
  before insert
  on M_ZONE_PATH
  for each row
begin       
select zonepath_seq.nextval into :new.id from dual;      
end ;
/

