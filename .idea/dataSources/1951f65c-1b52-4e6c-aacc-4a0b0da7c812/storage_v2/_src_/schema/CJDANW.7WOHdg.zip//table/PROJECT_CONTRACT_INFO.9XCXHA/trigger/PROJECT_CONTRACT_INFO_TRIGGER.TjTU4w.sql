create trigger PROJECT_CONTRACT_INFO_TRIGGER
  before insert
  on PROJECT_CONTRACT_INFO
  for each row
begin       
select PROJECT_CONTRACT_INFO_SEQ.nextval into :new.sort from dual;      
end ;
/

