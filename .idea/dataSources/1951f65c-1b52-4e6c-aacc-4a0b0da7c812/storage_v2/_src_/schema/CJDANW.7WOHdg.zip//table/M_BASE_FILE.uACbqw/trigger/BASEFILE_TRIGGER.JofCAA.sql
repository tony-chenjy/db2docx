create trigger BASEFILE_TRIGGER
  before insert
  on M_BASE_FILE
  for each row
begin       
select basefile_seq.nextval into :new.id from dual;      
end ;
/

